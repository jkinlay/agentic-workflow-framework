"""AWF Claude adapter tests."""
