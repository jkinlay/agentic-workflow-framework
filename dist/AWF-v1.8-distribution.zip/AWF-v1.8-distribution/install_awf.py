#!/usr/bin/env python3
"""Install AWF 1.8.0; forwards --dry-run, --dest and --backup-root."""
from pathlib import Path
import hashlib
import subprocess
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11 or later is required")
root = Path(__file__).resolve().parent / "awf"
for relative, expected in {"SKILL-MANIFEST.json": "d87d7859f1605a1c9955b2502c83d23b72a9823cd9eeab3eba07a3059e5bec5e", "scripts/install_skill.py": "ac4a27b3909bf13d434883dc8a12220c17a470afb3615714d493f6909a2e55dc"}.items():
    if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
        raise SystemExit("Distribution integrity failure: " + relative)
raise SystemExit(subprocess.call([sys.executable, "-B", str(root / "scripts/install_skill.py"), "--expected-manifest-sha256", "d87d7859f1605a1c9955b2502c83d23b72a9823cd9eeab3eba07a3059e5bec5e", *sys.argv[1:]]))
