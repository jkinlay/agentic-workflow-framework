#!/usr/bin/env python3
"""Install AWF 1.7.0; forwards --dry-run, --dest and --backup-root."""
from pathlib import Path
import hashlib
import subprocess
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11 or later is required")
root = Path(__file__).resolve().parent / "awf"
for relative, expected in {"SKILL-MANIFEST.json": "d7853718c4deeb2286a1e39d9d4a7356e7c0389af32a771fd25c74da29f4dc05", "scripts/install_skill.py": "ac4a27b3909bf13d434883dc8a12220c17a470afb3615714d493f6909a2e55dc"}.items():
    if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
        raise SystemExit("Distribution integrity failure: " + relative)
raise SystemExit(subprocess.call([sys.executable, "-B", str(root / "scripts/install_skill.py"), "--expected-manifest-sha256", "d7853718c4deeb2286a1e39d9d4a7356e7c0389af32a771fd25c74da29f4dc05", *sys.argv[1:]]))
