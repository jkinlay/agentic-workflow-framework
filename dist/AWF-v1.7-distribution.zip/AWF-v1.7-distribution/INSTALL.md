# Install AWF 1.7.0

Extract this complete distribution. With Python 3.11+ installed, run from this folder:

```text
python -B install_awf.py --dry-run
python -B install_awf.py
```

On Windows, `py -3 install_awf.py` is also supported. Use an absolute interpreter path if Python is not on PATH.
The launcher contains the package pins and verifies the installer before executing it. Verify the outer ZIP SHA-256 against the trusted delivery record before running downloaded code.

The installer reuses your user-level `awf` installation, stages and verifies the new package, retains the previous folder in an external backup and preserves local catalog/update-channel settings. Do not uninstall the prior skill first. Use `--dest ABSOLUTE_SKILLS_DIRECTORY/awf` to choose another installation. It does not remove other copies or plugins. See [installation and rollback](awf/references/skill-installation.md).

The skill will be available on your next turn; start a new Codex task if needed to refresh discovery. Invoke `$awf` and ask it to adopt AWF 1.7 in the intended project. Existing projects retain their version until separately migrated. The bundled source contains the applicable versioned migration guides.

Balanced routing selects models and effort by role/task/risk, escalates within configured limits and records usage/outcomes. Adaptive mode initially makes evidence-based recommendations. The host must support the chosen models and enforce actual run limits; synthetic tests do not establish model quality or live integration.

Skill manifest SHA-256: `d7853718c4deeb2286a1e39d9d4a7356e7c0389af32a771fd25c74da29f4dc05`

Release manifest SHA-256: `73e20cff9127fe1af5b19c6438a99f0a71fcd9816eb4fd319cf42f0e53728215`

Release ZIP SHA-256: `fc384c8209a760f11be033a94d577cfa279bec25d4d6af402a39ebc30ba29d93`

No personal paths, credentials or local settings are shipped. A copied update channel is a snapshot; future detection requires a maintained owner channel.
