#!/usr/bin/env python3
"""Install AWF 1.8.9; forwards --dry-run, --dest and --backup-root."""
from pathlib import Path
import hashlib
import subprocess
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11 or later is required")
root = Path(__file__).resolve().parent / "awf"
for relative, expected in {"SKILL-MANIFEST.json": "192c538a8f2f4e25e8e70edb99719c6e048eac9c46242e737f0a918a87b00c7d", "scripts/install_skill.py": "ac4a27b3909bf13d434883dc8a12220c17a470afb3615714d493f6909a2e55dc"}.items():
    if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
        raise SystemExit("Distribution integrity failure: " + relative)
raise SystemExit(subprocess.call([sys.executable, "-B", str(root / "scripts/install_skill.py"), "--expected-manifest-sha256", "192c538a8f2f4e25e8e70edb99719c6e048eac9c46242e737f0a918a87b00c7d", *sys.argv[1:]]))
