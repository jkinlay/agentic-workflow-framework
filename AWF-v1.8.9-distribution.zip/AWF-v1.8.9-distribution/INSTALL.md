# Install AWF 1.8.9

Extract this complete distribution. With Python 3.11+ installed, run from this folder:

```text
python -B install_awf.py --dry-run
python -B install_awf.py
```

On Windows, `py -3 install_awf.py` is also supported. Use an absolute interpreter path if Python is not on PATH.
The launcher contains package pins and verifies the installer before executing it. Verify the outer ZIP SHA-256 against an independently obtained delivery pin before running downloaded code. This distribution is unsigned: bundled hashes detect byte changes but do not authenticate Jonathan Kinlay as their publisher.

The installer reuses your user-level `awf` installation, stages and verifies the new package, retains the previous folder in an external backup and preserves local catalog/update-channel settings. Do not uninstall the prior skill first. Use `--dest ABSOLUTE_SKILLS_DIRECTORY/awf` to choose another installation. It does not remove other copies or plugins. See [installation and rollback](awf/references/skill-installation.md).

The skill will be available on your next turn; start a new Codex task if needed to refresh discovery. Invoke `$awf` and ask it to adopt AWF 1.8.9 in the intended project. Existing projects retain their version until separately migrated. The bundled source contains the applicable versioned migration guides.

Balanced routing selects models and effort by role/task/risk, escalates within configured limits and records usage/outcomes. Adaptive mode initially makes evidence-based recommendations. The host must support the chosen models and enforce actual run limits; synthetic tests do not establish model quality or live integration.

Skill manifest SHA-256: `192c538a8f2f4e25e8e70edb99719c6e048eac9c46242e737f0a918a87b00c7d`

Release manifest SHA-256: `f18aaac889455c2d6a0ae3668dd4a0cb11c54970658cd8017594844a50b56dbe`

Release ZIP SHA-256: `1ecfeff80bd305a937915738988d5b4a026353eb7ba1308e75e8ede5f6639dc2`

No personal paths, credentials or local settings are shipped. A copied update channel is a snapshot; future detection requires a maintained owner channel.
